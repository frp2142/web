"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Person = (function () {
    function Person(name, path, birthdate, bornIn, profession) {
        this.name = name;
        this.picturePath = path;
        this.birthdate = birthdate;
        this.bornIn = bornIn;
        this.profession = profession;
    }
    return Person;
}());
exports.Person = Person;
//# sourceMappingURL=Person.js.map